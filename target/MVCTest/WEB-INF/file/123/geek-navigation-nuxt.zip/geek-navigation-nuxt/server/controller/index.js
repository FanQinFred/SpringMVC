const user = require('./user')
const category = require('./category')
const nav = require('./nav')

module.exports = {
  user,
  category,
  nav,
}
